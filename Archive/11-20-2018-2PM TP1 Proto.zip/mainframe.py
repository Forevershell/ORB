#Project Map Based Pygame
import pygame
import math
#custom imports
import player
import board
import enemy

pygame.init()
pygame.font.init()

def createBoard(rows,cols):
    #Board is set in place, can change later based upon preferences
    board=[]
    for row in range(rows):
        board.append([])
        for col in range(cols):
            board[row].append(0)
            if row==0 or row==rows-1 or col==0 or col==cols-1:
                board[row][col]=1
    return board

#temp variables to be implemented in classes
rows=20
cols=10
size=25
rad=size//2
board=createBoard(rows,cols)

#colors
lightest=(89, 188, 202)
light=(51, 169, 185)
medium=(18, 155, 174)
dark=(2, 126, 143)
darkest=(2, 98, 111)
#enemy colors
colorE=(178,34,34)

#game init
game=pygame.display.set_mode((cols*size,rows*size))
pygame.display.set_caption("Game")
timeCount=0
phase=1
#player and enemy inits
p1=player.Player(cols//2,rows//2,math.pi/2)
enemies=[]
#screen parameters get
screenW=game.get_width()
screenH=game.get_height()

def getColor(row,col):
    tile=board[row][col]
    #tile is empty
    if tile==0:
        return lightest
    #tile is wall
    elif tile==1:
        return dark
    #tile is player
    elif tile==2:
        return darkest
    elif tile==3:
        return colorE
        
def redrawPhaseI():
    game.fill((255,255,255))
    myfont = pygame.font.SysFont('Comic Sans MS', 30)
    textsurface = myfont.render('Press P to Play', False, (0, 0, 0))
    game.blit(textsurface,(screenW/2,screenH/2))
    pygame.display.update()

def redrawPhaseII():
    for row in range(rows):
        for col in range(cols):
            pygame.draw.rect(game,getColor(row,col),\
            (col*size,row*size,(col+1)*size,(row+1)*size))
    lineI=((p1.x+0.5)*size,(p1.y+0.5)*size)
    lineF=((p1.x+0.5)*size+(math.cos(p1.angle))*size,\
        (p1.y+0.5)*size-(math.sin(p1.angle))*size)
    pygame.draw.line(game,darkest,lineI,lineF,5)
    for bullet in p1.bullets:
        bullet.draw(game,medium)
    pygame.display.update()

def redrawPhaseIII():
    game.fill(darkest)
    myfont = pygame.font.SysFont('Comic Sans MS', 30)
    textsurface = myfont.render('You suck', False, lightest)
    game.blit(textsurface,(screenW/2,screenH/2))
    pygame.display.update()

def reset():
    timeCount=0
    phase=1
    p1.x,p1.y,p1.angle=(cols//2,rows//2,math.pi/2)
    enemies=[]

run=True
timeCount=0
#mainloop
while run:
    pygame.time.delay(75)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    
    keys=pygame.key.get_pressed()
    
    ##Menu Phase
    if phase==1:
        if keys[pygame.K_p]:
            phase=2
        redrawPhaseI()
        
    ##Main Game Phase
    elif phase==2:
        #Movement
        oX,oY=p1.getPos()
        if keys[pygame.K_a] and oX>0:
            p1.mLeft()
            x,y=p1.getPos()
            if board[y][x]==1:
                p1.mRight()
        if keys[pygame.K_d] and oX<cols-1:
            p1.mRight()
            x,y=p1.getPos()
            if board[y][x]==1:
                p1.mLeft()
        if keys[pygame.K_w] and oY>0:
            p1.mUp()
            x,y=p1.getPos()
            if board[y][x]==1:
                p1.mDown()
        if keys[pygame.K_s] and oY<rows-1:
            p1.mDown()
            x,y=p1.getPos()
            if board[y][x]==1:
                p1.mUp()
        x,y=p1.getPos()
        board[oY][oX]=0
        board[y][x]=2
        
        #Turning
        if keys[pygame.K_LEFT]:
            p1.tLeft()
        if keys[pygame.K_RIGHT]:
            p1.tRight()
            
        #Shooting
        if keys[pygame.K_SPACE] and p1.shotTimer%10==0:
            p1.shoot()
        for bullet in p1.bullets:
            bullet.moveBullet()
            if bullet.checkOut(size,board):
                p1.bullets.remove(bullet)
                
        #Timer
        if timeCount%100==0:
            enemies.append(enemy.Enemy(board))
        for e in enemies:
            e.generate(board)
            if e.collide(x,y):
                phase=3
        
        timeCount+=1
        p1.timerIncrease()
        redrawPhaseII()
        
    ##End Game Phase
    elif phase==3:
        if keys[pygame.K_p]:
            phase=1
            reset()
        redrawPhaseIII()

pygame.quit()