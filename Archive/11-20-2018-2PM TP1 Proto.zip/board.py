#board
class Board:
    def __init__(self,size):
        self.size=size
        
    def createBoard(self):
        #Board is set in place, can change later based upon preferences
        board=[]
        rows=20
        cols=10
        for row in range(rows):
            board.append([])
            for col in range(cols):
                board[row].append(0)
                if row==0 or row==rows-1 or col==0 or col==cols-1:
                    board[row][col]=1
        return board