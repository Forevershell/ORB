import pygame
import math
import bullet

#bullet class
class Bullet():
    def __init__(self,x,y,angle):
        self.x=x
        self.y=y
        self.angle=angle
        self.vel=20
        self.rad=5
        
    def moveBullet(self):
        self.x+=int((math.cos(self.angle))*self.vel)
        self.y-=int((math.sin(self.angle))*self.vel)
        
    def checkOut(self,size,board):
        return board[self.y//size][self.x//size]==1

    def draw(self,surface,color):
        pygame.draw.circle(surface,color,(self.x,self.y),self.rad)