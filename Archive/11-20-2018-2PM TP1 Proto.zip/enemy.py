import backtracker
import random

#enemy class
#multiple types of enemy
class Enemy():
    def __init__(self,board):
        space=[]
        for row in range(len(board)):
            for col in range(len(board[row])):
                if board[row][col]==0:
                    space.append((col,row))
        self.x,self.y=random.choice(space)
        
    def generate(self,board):
        board[self.y][self.x]=3
    
    def collide(self,pX,pY):
        return (pX,pY)==(self.x,self.y)